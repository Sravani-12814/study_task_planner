import { useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowDownWideNarrow, ArrowUpRight, ListTodo, Check, ChevronDown, CircleHelp, Clock3, Command, FileText, FolderOpen, GraduationCap, LoaderCircle, Plus, Search, Sparkles, Trash2, X } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
const emptyForm = { name: '', description: '' };

async function request(path, options) {
  let response;
  try { response = await fetch(`${API}${path}`, { headers: { 'Content-Type': 'application/json', ...options?.headers }, ...options }); }
  catch { throw new Error('Could not reach the API. Check that the server and MongoDB are running.'); }
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.message || 'Something went wrong. Please try again.');
  return body;
}

function prettyDate(value) {
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value));
}

export default function App() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('newest');
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [mobileForm, setMobileForm] = useState(false);

  const loadItems = useCallback(async () => {
    setLoading(true);
    try { const result = await request('/items'); setItems(result.items); setError(''); }
    catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadItems(); }, [loadItems]);
  useEffect(() => { if (!notice) return; const timer = setTimeout(() => setNotice(''), 2800); return () => clearTimeout(timer); }, [notice]);

  const visibleItems = useMemo(() => {
    const term = search.trim().toLowerCase();
    return [...items].filter((item) => !term || `${item.name} ${item.description}`.toLowerCase().includes(term))
      .sort((a, b) => sort === 'oldest' ? new Date(a.createdAt) - new Date(b.createdAt) : new Date(b.createdAt) - new Date(a.createdAt));
  }, [items, search, sort]);

  function startEdit(item) {
    setEditing(item._id); setForm({ name: item.name, description: item.description }); setMobileForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function cancelEdit() { setEditing(null); setForm(emptyForm); }

  async function submit(event) {
    event.preventDefault(); setSaving(true); setError('');
    try {
      if (editing) {
        await request(`/items/${editing}`, { method: 'PUT', body: JSON.stringify(form) });
        setNotice('Task details updated');
      } else {
        await request('/items', { method: 'POST', body: JSON.stringify(form) });
        setNotice('Task added to your list');
      }
      cancelEdit(); await loadItems();
    } catch (err) { setError(err.message); }
    finally { setSaving(false); }
  }

  async function remove(item) {
    if (!window.confirm(`Delete “${item.name}” from your task list?`)) return;
    setDeleting(item._id); setError('');
    try { await request(`/items/${item._id}`, { method: 'DELETE' }); setNotice('Item deleted'); await loadItems(); }
    catch (err) { setError(err.message); }
    finally { setDeleting(''); }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Study Planner home"><span className="brand-mark"><ListTodo size={18} strokeWidth={2.2} /></span><span>plan<span className="brand-dot">.</span>it</span></a>
        <nav className="top-nav" aria-label="Main navigation"><a className="nav-active" href="#library">My tasks</a><a href="#about">About</a></nav>
        <div className="top-right"><span className="student-pill"><GraduationCap size={15} /> Study workspace</span><button className="avatar" aria-label="Student profile">S</button></div>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot" /> ONE STEP AT A TIME</div><h1>Make room for<br /><em>what matters.</em></h1><p>Keep your coursework and project tasks together, with details you will need later.</p><a className="hero-link" href="#library">See your task list <ArrowDownWideNarrow size={15} /></a></div>
          <div className="hero-art" aria-hidden="true"><div className="sun-disc" /><div className="art-note note-left"><span className="note-icon note-green"><Sparkles size={17} /></span><span>Stay curious</span><span className="note-lines" /></div><div className="art-note note-right"><span className="note-icon note-coral"><FileText size={16} /></span><span>Good ideas<br />live here</span></div><div className="book-stack"><div className="book book-one"><span>the art of</span><b>learning</b><i /></div><div className="book book-two"><span>FIELD NOTES</span><b>vol. 02</b></div><div className="book book-three"><span>MAKE SPACE</span><b>to think</b></div></div><div className="art-spark spark-one">✳</div><div className="art-spark spark-two">✦</div><div className="plant"><i /><i /><i /><b /></div><div className="art-caption">a work in progress <span>✳</span></div></div>
          <div className="hero-index"><span>01</span><i /> A SPACE OF YOUR OWN</div>
        </section>

        <section className="workspace" id="library">
          <aside className={`composer ${mobileForm ? 'composer-open' : ''}`}>
            <div className="composer-head"><div><span className="section-kicker">YOUR STUDY PLAN</span><h2>{editing ? 'Edit an item' : 'Add a task'}</h2></div><button className="mobile-close" onClick={() => setMobileForm(false)} aria-label="Close form"><X size={18} /></button><span className="add-orb"><Plus size={18} /></span></div>
            <p className="composer-intro">Add coursework, a deadline reminder, or a small next step.</p>
            <form onSubmit={submit} className="item-form">
              <label htmlFor="item-name">Task name</label><input id="item-name" autoComplete="off" maxLength="80" placeholder="e.g. Finish biology lab report" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required minLength="2" />
              <div className="label-row"><label htmlFor="item-description">Task details</label><span>{form.description.length}/500</span></div><textarea id="item-description" maxLength="500" placeholder="What do you need to remember?" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required minLength="3" rows="4" />
              <button className="submit-button" disabled={saving}>{saving ? <LoaderCircle className="spin" size={16} /> : editing ? <Check size={16} /> : <Plus size={16} />}{saving ? 'Saving…' : editing ? 'Save changes' : 'Add to my tasks'}<ArrowUpRight size={16} className="submit-arrow" /></button>
              {editing && <button type="button" className="cancel-edit" onClick={cancelEdit}>Cancel editing</button>}
            </form>
            <div className="aside-tip"><span><Sparkles size={16} /></span><p><b>A gentle reminder</b><br />Small steps add up. Pick one thing and get started.</p></div>
            <div className="margin-note">MAKE THE NEXT STEP CLEAR <span>↗</span></div>
          </aside>

          <div className="library-panel">
            <div className="library-heading"><div><span className="section-kicker">YOUR COURSEWORK SPACE</span><h2>Tasks to work on<span className="heading-period">.</span></h2></div><button className="mobile-add" onClick={() => setMobileForm(true)}><Plus size={16} /> Add task</button></div>
            <div className="collection-meta"><div className="count-label"><FolderOpen size={16} /><span><b>{items.length}</b> {items.length === 1 ? 'task planned' : 'tasks planned'}</span></div><div className="list-tools"><label className="search-box"><Search size={16} /><input aria-label="Search items" placeholder="Find a task…" value={search} onChange={(e) => setSearch(e.target.value)} /><kbd><Command size={10} /> K</kbd></label><label className="sort-box"><span className="sr-only">Sort items</span><select value={sort} onChange={(e) => setSort(e.target.value)}><option value="newest">Newest first</option><option value="oldest">Oldest first</option></select><ChevronDown size={13} /></label></div></div>
            {error && <div className="error-banner" role="alert"><CircleHelp size={16} /><span>{error}</span>{!items.length && !loading && <button onClick={loadItems}>Try again</button>}</div>}
            {loading ? <div className="loading-state"><LoaderCircle className="spin" size={20} /><span>Gathering your tasks…</span></div> : visibleItems.length ? <div className="item-list">{visibleItems.map((item, index) => <article className="item-card" key={item._id}><div className={`item-marker marker-${index % 4}`}><span>{String(index + 1).padStart(2, '0')}</span><i /></div><div className="item-content"><div className="item-topline"><span className="item-type"><FileText size={12} /> STUDY TASK</span><span className="item-date"><Clock3 size={13} /> {prettyDate(item.createdAt)}</span></div><h3>{item.name}</h3><p>{item.description}</p><div className="item-footer"><span className="saved-label"><span /> ON YOUR TASK LIST</span><div className="item-actions"><button onClick={() => startEdit(item)} aria-label={`Edit ${item.name}`}><FileText size={14} /> Edit</button><button className="delete-action" onClick={() => remove(item)} disabled={deleting === item._id} aria-label={`Delete ${item.name}`}>{deleting === item._id ? <LoaderCircle className="spin" size={14} /> : <Trash2 size={14} />} Delete</button></div></div></div></article>)}</div> : <div className="empty-state"><div className="empty-illustration"><div className="empty-sun" /><ListTodo size={34} strokeWidth={1.2} /><span>✳</span></div><span className="section-kicker">A FRESH START</span><h3>{search ? 'Nothing by that name…' : 'Your next accomplishment starts here.'}</h3><p>{search ? 'Try another search and see what turns up.' : 'Start with one task you want to finish. Add details to make the next step easy.'}</p>{search ? <button onClick={() => setSearch('')}>Clear search</button> : <button onClick={() => document.getElementById('item-name')?.focus()}>Add your first task <ArrowUpRight size={15} /></button>}</div>}
            <footer className="list-footer"><span>MADE FOR YOUR NEXT STEP</span><span><i /> KEEP MAKING PROGRESS</span></footer>
          </div>
        </section>
      </main>
      <footer className="site-footer" id="about"><a className="footer-brand" href="#top"><ListTodo size={15} /> plan.it</a><span>A little space to make progress.</span><span>Built for busy students <span className="footer-star">✳</span></span></footer>
      {notice && <div className="toast" role="status"><span><Check size={14} /></span>{notice}</div>}
      {mobileForm && <button className={`scrim ${mobileForm ? 'scrim-open' : ''}`} aria-label="Close form" onClick={() => setMobileForm(false)} />}
    </div>
  );
}




