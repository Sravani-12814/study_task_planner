import mongoose from 'mongoose';

const itemSchema = new mongoose.Schema({
  name: { type: String, required: [true, 'Name is required'], trim: true, minlength: [2, 'Name must be at least 2 characters'], maxlength: [80, 'Name must be 80 characters or fewer'] },
  description: { type: String, required: [true, 'Description is required'], trim: true, minlength: [3, 'Description must be at least 3 characters'], maxlength: [500, 'Description must be 500 characters or fewer'] },
}, { timestamps: true, versionKey: false });

export default mongoose.model('Item', itemSchema);
