export function notFound(req, res) {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
}

export function errorHandler(error, req, res, next) {
  console.error(error);
  if (res.headersSent) return next(error);
  if (error.name === 'ValidationError') return res.status(400).json({ message: Object.values(error.errors).map((entry) => entry.message).join(' ') });
  if (error.name === 'CastError') return res.status(400).json({ message: 'The supplied value is not valid.' });
  const status = error.status || 500;
  res.status(status).json({ message: status === 500 ? 'Something went wrong on the server.' : error.message });
}
