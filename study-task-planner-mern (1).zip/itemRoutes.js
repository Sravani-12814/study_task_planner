import { Router } from 'express';
import mongoose from 'mongoose';
import Item from '../models/Item.js';

const router = Router();
const validId = (id) => mongoose.isValidObjectId(id);
const fieldsFrom = (body) => {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return null;
  const { name, description } = body;
  if (typeof name !== 'string' || typeof description !== 'string') return null;
  const clean = { name: name.trim(), description: description.trim() };
  if (clean.name.length < 2 || clean.name.length > 80) return null;
  if (clean.description.length < 3 || clean.description.length > 500) return null;
  return clean;
};

router.get('/', async (req, res, next) => {
  try {
    const search = typeof req.query.search === 'string' ? req.query.search.trim().slice(0, 80) : '';
    const filter = search ? { $or: [{ name: { $regex: escapeRegex(search), $options: 'i' } }, { description: { $regex: escapeRegex(search), $options: 'i' } }] } : {};
    const items = await Item.find(filter).sort({ createdAt: -1 }).limit(200).lean();
    res.json({ items });
  } catch (error) { next(error); }
});

router.get('/:id', async (req, res, next) => {
  try {
    if (!validId(req.params.id)) return res.status(400).json({ message: 'That item ID is not valid.' });
    const item = await Item.findById(req.params.id).lean();
    if (!item) return res.status(404).json({ message: 'Item not found.' });
    res.json({ item });
  } catch (error) { next(error); }
});

router.post('/', async (req, res, next) => {
  const fields = fieldsFrom(req.body);
  if (!fields) return res.status(400).json({ message: 'Enter a name (2–80 characters) and description (3–500 characters).' });
  try { const item = await Item.create(fields); res.status(201).json({ item }); }
  catch (error) { next(error); }
});

router.put('/:id', async (req, res, next) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: 'That item ID is not valid.' });
  const fields = fieldsFrom(req.body);
  if (!fields) return res.status(400).json({ message: 'Enter a name (2–80 characters) and description (3–500 characters).' });
  try {
    const item = await Item.findByIdAndUpdate(req.params.id, fields, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ message: 'Item not found.' });
    res.json({ item });
  } catch (error) { next(error); }
});

router.delete('/:id', async (req, res, next) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: 'That item ID is not valid.' });
  try {
    const item = await Item.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found.' });
    res.json({ message: 'Item deleted.' });
  } catch (error) { next(error); }
});

function escapeRegex(value) { return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
export default router;
